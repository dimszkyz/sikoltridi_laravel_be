<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sikoltridi</title>
    <link rel="icon" type="image/png" href="/logo.png" />
    @viteReactRefresh
    
    {{-- Ubah path ini agar sama persis dengan input di vite.config.js --}}
    @vite('src/main.jsx')
</head>
<body>
    <div id="root"></div>
</body>
</html>